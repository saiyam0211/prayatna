#!/bin/bash

# Prayatna Backend Server Startup Script
echo "🚀 Starting Prayatna Backend Server..."

export MONGODB_URI="mongodb+srv://saiyamkumar2007:Saiyam12@cluster0.x9jcmnx.mongodb.net/prayatna"
export JWT_SECRET="prayatna-super-secret-jwt-key-2024-production-ready"
export PORT=3001
export NODE_ENV=development

# Twilio Configuration
export TWILIO_ACCOUNT_SID="AC7b3bbc1391c89cd8363e0df13cd35569"
export TWILIO_AUTH_TOKEN="48db31e602ffc36d4b4303b4265e5ad2"
export TWILIO_PHONE_NUMBER="+917488966339"
export TWILIO_VERIFY_SERVICE_SID="VA6b64d9dc6920128b9ec7af3d713bb1d5"

# Default School Credentials
export DEFAULT_SCHOOL_ID="PRAYATNA2024"
export DEFAULT_SCHOOL_PASSWORD="admin123"

# Frontend URL
export FRONTEND_URL="http://localhost:5173"

# Rate Limiting
export RATE_LIMIT_WINDOW_MS=900000
export RATE_LIMIT_MAX_REQUESTS=100

# Content Moderation
export CONTENT_MODERATION_ENABLED=true
export AUTO_APPROVE_TEACHER_POSTS=true

echo "✅ Environment variables set"
echo "📱 Starting server on port $PORT..."

node server.js 